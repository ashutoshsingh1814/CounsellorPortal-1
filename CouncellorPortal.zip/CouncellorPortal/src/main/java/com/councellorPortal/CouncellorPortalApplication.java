package com.councellorPortal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CouncellorPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(CouncellorPortalApplication.class, args);
	}

}
