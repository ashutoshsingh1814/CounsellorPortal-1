package com.councellorPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouncellorPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
